# Plataforma CRM de Prospecção – Paraná

Aplicação web estática pronta para implantação.

## Recursos
- Base inicial de 200 leads
- CRM e edição de leads
- Funil comercial
- Dashboard automático
- Gráfico de pizza e barras
- Filtros e busca
- Follow-ups
- Prioridade inteligente baseada em regras
- Persistência local no navegador
- Sincronização entre abas do mesmo navegador
- Importação e exportação CSV

## Publicação
Pode ser publicada como site estático em Vercel, Netlify, GitHub Pages ou qualquer hospedagem web.

Para produção com múltiplos usuários e atualização em tempo real entre dispositivos, conecte um banco de dados e autenticação. A aplicação atual foi construída para funcionar imediatamente sem servidor.
